package com.thilini.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thilini.sms.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
