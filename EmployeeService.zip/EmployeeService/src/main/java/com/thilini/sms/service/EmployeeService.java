package com.thilini.sms.service;

import java.util.List;

import com.thilini.sms.model.Employee;

public interface EmployeeService {

	public Employee save(Employee employee);

	public List<Employee> fetchAllEmployees();

	public Employee fetchEmployees(Employee employee);
	
}
