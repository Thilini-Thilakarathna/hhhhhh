package com.thilini.sms.service;

import java.util.List;
import java.util.Optional;

import com.thilini.sms.model.Allocation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.stereotype.Service;

import com.thilini.sms.model.Employee;
import com.thilini.sms.model.Telephone;
import com.thilini.sms.repository.EmployeeRepository;
import org.springframework.web.client.RestTemplate;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee save(Employee employee) {
		
		for(Telephone tel: employee.getTelephone()){
			tel.setEmployee(employee);
		}
	
	return	employeeRepository.save(employee);
	
	}

	@Override
	public List<Employee> fetchAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee fetchEmployees(Employee employee) {
	Optional<Employee> optional= employeeRepository.findById(employee.getId());
	if(optional.isPresent()){

		RestTemplate restTemplate= new RestTemplate();
		HttpHeaders httpHeaders= new HttpHeaders();
		OAuth2AuthenticationDetails oAuth2AuthenticationDetails= (OAuth2AuthenticationDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
		System.out.println(">>>>>"+oAuth2AuthenticationDetails.getTokenValue());
		httpHeaders.add("Authorization","bearer".concat(oAuth2AuthenticationDetails.getTokenValue()));

		ResponseEntity<Allocation[]> responseEntity;
		HttpEntity<String> httpEntity= new HttpEntity<>("",httpHeaders);
		responseEntity= restTemplate.exchange("http://localhost:9093/ascloud/allocations/".concat(employee.getId().toString()), HttpMethod.GET,httpEntity,Allocation[].class);

		Employee employee1= optional.get();
		employee1.setAllocations(responseEntity.getBody());

		return employee1;
	}else{
		return null;
	}
	}

	
	

	
	
}
